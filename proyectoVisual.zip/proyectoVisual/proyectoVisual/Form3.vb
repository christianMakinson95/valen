﻿Public Class formJuego
    Dim cartasJugador(0 To 4) As Integer
    Dim cartasMaquina(0 To 4) As Integer
    Dim maximo = 11
    Dim minimo = 1
    Dim cantidadDeVecesQuePidio = 0
    Dim manoActual = 1
    Dim cantidadDeManos = cuantasManosHay()
    Dim valorDeMano = 0

    Private Sub formJuego_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        inicializarJuego()
        If cantidadDeManos = 5 Then
            lblTipoPartida.Text &= "Partida Corta"
        Else
            lblTipoPartida.Text &= "Partida Larga"
        End If
    End Sub



    Private Sub btnPedirCarta_Click(sender As Object, e As EventArgs) Handles btnPedirCarta.Click

        If cantidadDeVecesQuePidio < 3 Then
            Dim carta = crearCarta(1, 11)
            cartasJugador(cantidadDeVecesQuePidio + 2) = carta
            agregarCartaACombo(cartasJugador(cantidadDeVecesQuePidio + 2))
            lblValorMano.Text = "Valor de Tu Mano: " & calcularMano(cartasJugador).ToString
            cantidadDeVecesQuePidio = cantidadDeVecesQuePidio + 1
        Else
            MessageBox.Show("Ya no podes pedir mas cartas", "Error")
        End If

        If calcularMano(cartasJugador) > 21 Then
            MessageBox.Show("Perdiste por pasarte de 21", "Fin de Mano")
            If manoActual < 5 Then
                manoActual = manoActual + 1
                mostrarCuantasManosQuedan()
                inicializarJuego()
            Else
                MessageBox.Show("Se termino el juego", "Fin de Partida")
            End If

        End If
    End Sub


    Private Sub btnFinMano_Click(sender As Object, e As EventArgs) Handles btnFinMano.Click
        lblCartaUnoMaquina.Show()
        lblCartaDosMaquina.Show()
        lblValorManoMaquina.Show()


        If calcularMano(cartasMaquina) > 21 And calcularMano(cartasJugador) < 21 Then
            MessageBox.Show("Ganaste la mano", "Fin de Mano")
        ElseIf calcularMano(cartasJugador) > calcularMano(cartasMaquina) Then
            MessageBox.Show("Ganaste la mano", "Fin de Mano")
        Else
            MessageBox.Show("Perdiste la mano", "Fin de Mano")
        End If

        If manoActual < cantidadDeManos Then
            manoActual += 1
            mostrarCuantasManosQuedan()
            inicializarJuego()
        Else
            MessageBox.Show("Se termino el juego", "Fin de Partida")
            Me.Hide()
            formFinDeJuego.Show()
        End If


    End Sub

    Function calcularMano(cartasJugador)
        Dim resultado = 0
        For i As Integer = 0 To 4
            resultado += cartasJugador(i)
        Next
        Return resultado
    End Function

    Sub agregarCartaACombo(carta)
        cmbCartasRepartidas.Items.Add(carta)
    End Sub

    Function crearCarta(minimo, maximo)
        Randomize()
        Return CInt(Int((maximo * Rnd()) + minimo))

    End Function

    Function cuantasManosHay()
        If formReglas.rbPartidaCorta.Checked Then
            Return 5
        Else
            Return 10
        End If
    End Function

    Sub mostrarCuantasManosQuedan()
        lblManoActual.Text = ""
        lblManoActual.Text &= "Mano Actual: " & manoActual.ToString & " (quedan " & (cantidadDeManos - manoActual).ToString & ")"
    End Sub

    'Le mando la mano de quien sea y la inicializo (le doy las primeras dos cartas)
    Sub repartirCartasIniciales(ByRef cartasDeAlguien)
        cartasDeAlguien(0) = crearCarta(minimo, maximo)
        cartasDeAlguien(1) = crearCarta(minimo, maximo)
    End Sub

    Sub inicializarJuego()
        cmbCartasRepartidas.Items.Clear()
        valorDeMano = 0
        lblValorMano.Text = "Valor de tu mano"
        If manoActual = cantidadDeManos Then
            MessageBox.Show("Se termino el juego", "Fin de Partida")
            Me.Hide()
            formFinDeJuego.Show()
        End If
        cartasJugador.Initialize()
        cartasMaquina.Initialize()
        lblCartaUnoMaquina.Hide()
        lblCartaDosMaquina.Hide()
        lblValorManoMaquina.Hide()
        repartirCartasIniciales(cartasJugador)
        agregarCartaACombo(cartasJugador(0))
        agregarCartaACombo(cartasJugador(1))
        valorDeMano = calcularMano(cartasJugador)
        lblValorMano.Text = "Valor de Tu Mano: " & calcularMano(cartasJugador).ToString
        repartirCartasIniciales(cartasMaquina)
        lblValorManoMaquina.Text = "Valor Mano de la Maquina: " & calcularMano(cartasMaquina).ToString
        lblCartaUnoMaquina.Text = "Carta Uno Maquina: "
        lblCartaUnoMaquina.Text &= cartasMaquina(0).ToString
        lblCartaDosMaquina.Text = "Carta Dos Maquina: "
        lblCartaDosMaquina.Text &= cartasMaquina(1).ToString
        mostrarCuantasManosQuedan()
    End Sub


End Class


