﻿Imports System.Timers
Public Class formJuego
    'Guardo mis cartas en dos arreglos distintos con 5 posiciones
    Dim cartasJugador(0 To 4) As Integer
    Dim cartasMaquina(0 To 4) As Integer
    'Mi carta maxima vale 11 (el As usado como 11), el minimo 1 (el As como 1)
    Dim maximo = 11
    Dim minimo = 1
    Dim cantidadDeVecesQuePidio = 0
    Dim manoActual = 0
    Dim cantidadDeManos = cuantasManosHay()
    Dim valorDeMano = 0
    'Estas variables van a ser publicas para que pueda usarlas donde quiera
    Public cantidadDeManosGanadas = 0
    Public cantidadDeManosPerdidas = 0
    Dim cantidadDeVecesTimer = 0
    Dim timer As Timer = New Timer()

    Private Sub formJuego_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'No quiero que aparezcan, solo las uso para guardar info y usarla en el form final
        lblGanadas.Hide()
        lblPerdidas.Hide()

        'Inicializo el timer y le digo que dura 15 segundos 
        'Al Final de ese tiempo se ejecuta TimerEvent

        timer.Interval = 15000
        AddHandler timer.Elapsed, AddressOf TimerEvent
        timer.AutoReset = True
        timer.Enabled = True

        gboxJugador.Text &= formTitulo.txtBoxNombre.Text

        'Divido el progress bar en la cantidad de manos de la partida
        pbarJuego.Step = 100 / cantidadDeManos
        pbarJuego.PerformStep()
        inicializarJuego()

        If cantidadDeManos = 5 Then
            lblTipoPartida.Text &= "Partida Corta"
        Else
            lblTipoPartida.Text &= "Partida Larga"
        End If
    End Sub



    Private Sub btnPedirCarta_Click(sender As Object, e As EventArgs) Handles btnPedirCarta.Click

        'Le reparten 2 cartas de inicio asi que tiene 3 veces para pedir
        If cantidadDeVecesQuePidio < 3 Then
            Dim carta = crearCarta(1, 11)
            'guardo la carta en el lugar correspondiente (2 posiciones mas que 
            'la cantidad de veces que pidio)
            cartasJugador(cantidadDeVecesQuePidio + 2) = carta
            agregarCartaACombo(cartasJugador(cantidadDeVecesQuePidio + 2))
            lblValorMano.Text = "Valor de Tu Mano: " & calcularMano(cartasJugador).ToString
            cantidadDeVecesQuePidio = cantidadDeVecesQuePidio + 1
        Else
            MessageBox.Show("Ya no podes pedir mas cartas", "Error")
        End If
        'Tengo que verificar que al pedir cartas no me pase de 21 que seria perder
        verificarQueNoPase21()
    End Sub


    Private Sub btnFinMano_Click(sender As Object, e As EventArgs) Handles btnFinMano.Click
        'Cuando termina la mano puedo ver las cartas de la maquina
        lblCartaUnoMaquina.Show()
        lblCartaDosMaquina.Show()
        lblValorManoMaquina.Show()


        If calcularMano(cartasMaquina) > 21 And calcularMano(cartasJugador) < 21 Then
            MessageBox.Show("Ganaste la mano", "Fin de Mano")
            cantidadDeManosGanadas += 1
            lblGanadas.Text = cantidadDeManosGanadas
        ElseIf calcularMano(cartasJugador) > calcularMano(cartasMaquina) Then
            MessageBox.Show("Ganaste la mano", "Fin de Mano")
            cantidadDeManosGanadas += 1
            lblGanadas.Text = cantidadDeManosGanadas
        Else
            MessageBox.Show("Perdiste la mano", "Fin de Mano")
            cantidadDeManosPerdidas += 1
            lblPerdidas.Text = cantidadDeManosPerdidas
        End If

        'Si quedan manos por jugar 
        If manoActual <= cantidadDeManos Then
            pbarJuego.PerformStep()
            mostrarCuantasManosQuedan()
            inicializarJuego()
            'sino
        Else
            MessageBox.Show("Se termino el juego", "Fin de Partida")
            timer.Enabled = False
            Me.Hide()
            formFinDeJuego.Show()
        End If
    End Sub

    'Funcion que suma todos los elementos de un arreglo
    Function calcularMano(cartasJugador)
        Dim resultado = 0
        For i As Integer = 0 To 4
            resultado += cartasJugador(i)
        Next
        Return resultado
    End Function

    Sub agregarCartaACombo(carta)
        cmbCartasRepartidas.Items.Add(carta)
    End Sub

    Function crearCarta(minimo, maximo)
        'Uso Randomize para que quede aleatorio real, solo con Rnd repite mucho
        Randomize()
        Return CInt(Int((maximo * Rnd()) + minimo))
    End Function

    Function cuantasManosHay()
        If formReglas.rbPartidaCorta.Checked Then
            Return 5
        Else
            Return 10
        End If
    End Function

    Sub mostrarCuantasManosQuedan()
        lblManoActual.Text = ""
        lblManoActual.Text &= "Mano Actual: " & manoActual.ToString & " (quedan " & (cantidadDeManos - manoActual).ToString & ")"
    End Sub

    'Le mando la mano de quien sea y la inicializo (le doy las primeras dos cartas)
    Sub repartirCartasIniciales(ByRef cartasDeAlguien)
        cartasDeAlguien(0) = crearCarta(minimo, maximo)
        cartasDeAlguien(1) = crearCarta(minimo, maximo)
    End Sub

    Sub inicializarJuego()
        manoActual += 1
        cantidadDeVecesQuePidio = 0
        cmbCartasRepartidas.Items.Clear()
        valorDeMano = 0
        lblValorMano.Text = "Valor de tu mano"
        If manoActual = cantidadDeManos + 1 Then
            MessageBox.Show("Se termino el juego", "Fin de Partida")
            timer.Enabled = False
            Me.Hide()
            formFinDeJuego.Show()
        End If
        cartasJugador = {0, 0, 0, 0, 0}
        cartasMaquina = {0, 0, 0, 0, 0}
        lblCartaUnoMaquina.Hide()
        lblCartaDosMaquina.Hide()
        lblValorManoMaquina.Hide()
        repartirCartasIniciales(cartasJugador)
        agregarCartaACombo(cartasJugador(0))
        agregarCartaACombo(cartasJugador(1))
        valorDeMano = calcularMano(cartasJugador)
        lblValorMano.Text = "Valor de Tu Mano: " & calcularMano(cartasJugador).ToString
        repartirCartasIniciales(cartasMaquina)
        lblValorManoMaquina.Text = "Valor Mano de la Maquina: " & calcularMano(cartasMaquina).ToString
        lblCartaUnoMaquina.Text = "Carta Uno Maquina: "
        lblCartaUnoMaquina.Text &= cartasMaquina(0).ToString
        lblCartaDosMaquina.Text = "Carta Dos Maquina: "
        lblCartaDosMaquina.Text &= cartasMaquina(1).ToString
        mostrarCuantasManosQuedan()
        verificarQueNoPase21()
    End Sub

    Sub verificarQueNoPase21()
        If calcularMano(cartasJugador) > 21 Then
            MessageBox.Show("Perdiste por pasarte de 21", "Fin de Mano")
            cantidadDeManosPerdidas += 1
            lblPerdidas.Text = cantidadDeManosPerdidas
            If manoActual < 5 Then
                pbarJuego.PerformStep()
                mostrarCuantasManosQuedan()
                inicializarJuego()
            Else
                MessageBox.Show("Se termino el juego", "Fin de Partida")
                timer.Enabled = False
                Me.Hide()
                formFinDeJuego.Show()
            End If

        End If
    End Sub

    Private Sub TimerEvent(sender As Object, e As EventArgs)
        MessageBox.Show("Pasaron 15 segundos", "Timer")
    End Sub


End Class


