﻿Public Class formFinDeJuego
    'Traigo las variables que necesito desde formJuego

    Dim ganadas As Integer = formJuego.lblGanadas.Text
    Dim perdidas As Integer = formJuego.lblPerdidas.Text
    Dim nombre = formTitulo.txtBoxNombre.Text
    Private Sub formFinDeJuego_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If ganadas > perdidas Then
            lblResultado.Text = "Felicidades " & nombre & vbCrLf & " ganaste con " & ganadas & " partidas ganadas"
        ElseIf ganadas < perdidas Then
            lblResultado.Text = "Que lastima " & nombre & vbCrLf & " perdiste con " & perdidas & " partidas perdidas"
        Else
            lblResultado.Text = "Empataste " & nombre
        End If
    End Sub

    Private Sub btnInicio_Click(sender As Object, e As EventArgs) Handles btnInicio.Click
        Me.Hide()
        formTitulo.Show()
    End Sub

    Private Sub btnReglas_Click(sender As Object, e As EventArgs) Handles btnReglas.Click
        Me.Hide()
        formReglas.Show()
    End Sub

    Private Sub btnJugar_Click(sender As Object, e As EventArgs) Handles btnJugar.Click
        Me.Hide()
        Application.Restart()
        formJuego.Show()
    End Sub
End Class