﻿Public Class formTitulo
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnIrAReglas_Click(sender As Object, e As EventArgs) Handles btnIrAReglas.Click
        Dim nombreJugador As String
        nombreJugador = txtBoxNombre.Text
        If nombreJugador Is "" Then
            MessageBox.Show("Por favor ingrese un nombre", "Error")
        Else
            Me.Hide()
            formReglas.Show()
        End If
    End Sub


End Class
