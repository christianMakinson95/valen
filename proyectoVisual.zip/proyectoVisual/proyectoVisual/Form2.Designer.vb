﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formReglas
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTextoReglas = New System.Windows.Forms.Label()
        Me.lblNombreJugador = New System.Windows.Forms.Label()
        Me.rbPartidaCorta = New System.Windows.Forms.RadioButton()
        Me.rbPartidaLarga = New System.Windows.Forms.RadioButton()
        Me.btnIrJuego = New System.Windows.Forms.Button()
        Me.btnVolverInicio = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTextoReglas
        '
        Me.lblTextoReglas.AutoSize = True
        Me.lblTextoReglas.Location = New System.Drawing.Point(13, 13)
        Me.lblTextoReglas.Name = "lblTextoReglas"
        Me.lblTextoReglas.Size = New System.Drawing.Size(111, 13)
        Me.lblTextoReglas.TabIndex = 0
        Me.lblTextoReglas.Text = "El juego consiste en..."
        '
        'lblNombreJugador
        '
        Me.lblNombreJugador.AutoSize = True
        Me.lblNombreJugador.Location = New System.Drawing.Point(582, 13)
        Me.lblNombreJugador.Name = "lblNombreJugador"
        Me.lblNombreJugador.Size = New System.Drawing.Size(50, 13)
        Me.lblNombreJugador.TabIndex = 1
        Me.lblNombreJugador.Text = "Nombre: "
        '
        'rbPartidaCorta
        '
        Me.rbPartidaCorta.AutoSize = True
        Me.rbPartidaCorta.Location = New System.Drawing.Point(16, 83)
        Me.rbPartidaCorta.Name = "rbPartidaCorta"
        Me.rbPartidaCorta.Size = New System.Drawing.Size(135, 17)
        Me.rbPartidaCorta.TabIndex = 2
        Me.rbPartidaCorta.TabStop = True
        Me.rbPartidaCorta.Text = "Partida Corta (5 manos)"
        Me.rbPartidaCorta.UseVisualStyleBackColor = True
        '
        'rbPartidaLarga
        '
        Me.rbPartidaLarga.AutoSize = True
        Me.rbPartidaLarga.Location = New System.Drawing.Point(16, 128)
        Me.rbPartidaLarga.Name = "rbPartidaLarga"
        Me.rbPartidaLarga.Size = New System.Drawing.Size(143, 17)
        Me.rbPartidaLarga.TabIndex = 3
        Me.rbPartidaLarga.TabStop = True
        Me.rbPartidaLarga.Text = "Partida Larga (10 manos)"
        Me.rbPartidaLarga.UseVisualStyleBackColor = True
        '
        'btnIrJuego
        '
        Me.btnIrJuego.Location = New System.Drawing.Point(280, 83)
        Me.btnIrJuego.Name = "btnIrJuego"
        Me.btnIrJuego.Size = New System.Drawing.Size(75, 23)
        Me.btnIrJuego.TabIndex = 4
        Me.btnIrJuego.Text = "Ir al Juego"
        Me.btnIrJuego.UseVisualStyleBackColor = True
        '
        'btnVolverInicio
        '
        Me.btnVolverInicio.Location = New System.Drawing.Point(280, 128)
        Me.btnVolverInicio.Name = "btnVolverInicio"
        Me.btnVolverInicio.Size = New System.Drawing.Size(113, 23)
        Me.btnVolverInicio.TabIndex = 5
        Me.btnVolverInicio.Text = "Volver al Inicio"
        Me.btnVolverInicio.UseVisualStyleBackColor = True
        '
        'formReglas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.proyectoVisual.My.Resources.Resources.blackJack
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnVolverInicio)
        Me.Controls.Add(Me.btnIrJuego)
        Me.Controls.Add(Me.rbPartidaLarga)
        Me.Controls.Add(Me.rbPartidaCorta)
        Me.Controls.Add(Me.lblNombreJugador)
        Me.Controls.Add(Me.lblTextoReglas)
        Me.Name = "formReglas"
        Me.Text = "Reglas"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTextoReglas As Label
    Friend WithEvents lblNombreJugador As Label
    Friend WithEvents rbPartidaCorta As RadioButton
    Friend WithEvents rbPartidaLarga As RadioButton
    Friend WithEvents btnIrJuego As Button
    Friend WithEvents btnVolverInicio As Button
End Class
