﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formFinDeJuego
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblResultado = New System.Windows.Forms.Label()
        Me.btnInicio = New System.Windows.Forms.Button()
        Me.btnReglas = New System.Windows.Forms.Button()
        Me.btnJugar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblResultado
        '
        Me.lblResultado.AutoSize = True
        Me.lblResultado.BackColor = System.Drawing.SystemColors.HotTrack
        Me.lblResultado.Location = New System.Drawing.Point(22, 38)
        Me.lblResultado.Name = "lblResultado"
        Me.lblResultado.Size = New System.Drawing.Size(0, 13)
        Me.lblResultado.TabIndex = 0
        '
        'btnInicio
        '
        Me.btnInicio.Location = New System.Drawing.Point(39, 89)
        Me.btnInicio.Name = "btnInicio"
        Me.btnInicio.Size = New System.Drawing.Size(161, 23)
        Me.btnInicio.TabIndex = 1
        Me.btnInicio.Text = "Volver al Inicio"
        Me.btnInicio.UseVisualStyleBackColor = True
        '
        'btnReglas
        '
        Me.btnReglas.Location = New System.Drawing.Point(39, 136)
        Me.btnReglas.Name = "btnReglas"
        Me.btnReglas.Size = New System.Drawing.Size(161, 23)
        Me.btnReglas.TabIndex = 2
        Me.btnReglas.Text = "Volver a las Reglas"
        Me.btnReglas.UseVisualStyleBackColor = True
        '
        'btnJugar
        '
        Me.btnJugar.Location = New System.Drawing.Point(39, 178)
        Me.btnJugar.Name = "btnJugar"
        Me.btnJugar.Size = New System.Drawing.Size(161, 23)
        Me.btnJugar.TabIndex = 3
        Me.btnJugar.Text = "Volver a Jugar"
        Me.btnJugar.UseVisualStyleBackColor = True
        '
        'formFinDeJuego
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(249, 269)
        Me.Controls.Add(Me.btnJugar)
        Me.Controls.Add(Me.btnReglas)
        Me.Controls.Add(Me.btnInicio)
        Me.Controls.Add(Me.lblResultado)
        Me.Name = "formFinDeJuego"
        Me.Text = "FinDeJuego"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblResultado As Label
    Friend WithEvents btnInicio As Button
    Friend WithEvents btnReglas As Button
    Friend WithEvents btnJugar As Button
End Class
