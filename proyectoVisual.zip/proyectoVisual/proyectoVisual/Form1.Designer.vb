﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formTitulo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNombre = New System.Windows.Forms.Label()
        Me.lblTextoBienvenida = New System.Windows.Forms.Label()
        Me.txtBoxNombre = New System.Windows.Forms.TextBox()
        Me.btnIrAReglas = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Location = New System.Drawing.Point(12, 26)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(47, 13)
        Me.lblNombre.TabIndex = 0
        Me.lblNombre.Text = "Nombre:"
        '
        'lblTextoBienvenida
        '
        Me.lblTextoBienvenida.Location = New System.Drawing.Point(12, 57)
        Me.lblTextoBienvenida.Name = "lblTextoBienvenida"
        Me.lblTextoBienvenida.Size = New System.Drawing.Size(632, 27)
        Me.lblTextoBienvenida.TabIndex = 1
        Me.lblTextoBienvenida.Text = "Bienvenidos a el Juego black Jack. A continuacion podran ver las reglas. Antes de" &
    " avanzar por favor ingrese los datos seleccionado"
        '
        'txtBoxNombre
        '
        Me.txtBoxNombre.Location = New System.Drawing.Point(75, 23)
        Me.txtBoxNombre.Name = "txtBoxNombre"
        Me.txtBoxNombre.Size = New System.Drawing.Size(100, 20)
        Me.txtBoxNombre.TabIndex = 2
        '
        'btnIrAReglas
        '
        Me.btnIrAReglas.Location = New System.Drawing.Point(15, 122)
        Me.btnIrAReglas.Name = "btnIrAReglas"
        Me.btnIrAReglas.Size = New System.Drawing.Size(75, 23)
        Me.btnIrAReglas.TabIndex = 3
        Me.btnIrAReglas.Text = "Ir a Reglas"
        Me.btnIrAReglas.UseVisualStyleBackColor = True
        '
        'formTitulo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.proyectoVisual.My.Resources.Resources.blackJack
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(783, 489)
        Me.Controls.Add(Me.btnIrAReglas)
        Me.Controls.Add(Me.txtBoxNombre)
        Me.Controls.Add(Me.lblTextoBienvenida)
        Me.Controls.Add(Me.lblNombre)
        Me.Name = "formTitulo"
        Me.Text = "BlackJack"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNombre As Label
    Friend WithEvents lblTextoBienvenida As Label
    Friend WithEvents txtBoxNombre As TextBox
    Friend WithEvents btnIrAReglas As Button
End Class
