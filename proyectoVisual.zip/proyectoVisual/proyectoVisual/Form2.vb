﻿Public Class formReglas
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblNombreJugador.Text = "Nombre: " & formTitulo.txtBoxNombre.Text
    End Sub

    
    Private Sub btnIrJuego_Click(sender As Object, e As EventArgs) Handles btnIrJuego.Click
        Me.Hide()
        formJuego.Show()
    End Sub

    Private Sub btnVolverInicio_Click(sender As Object, e As EventArgs) Handles btnVolverInicio.Click
        Me.Hide()
        formTitulo.Show()
    End Sub
End Class






