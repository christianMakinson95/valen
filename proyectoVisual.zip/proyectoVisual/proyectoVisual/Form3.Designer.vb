﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formJuego
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblTipoPartida = New System.Windows.Forms.Label()
        Me.cmbCartasRepartidas = New System.Windows.Forms.ComboBox()
        Me.lblValorMano = New System.Windows.Forms.Label()
        Me.lblCartasRepartidas = New System.Windows.Forms.Label()
        Me.btnPedirCarta = New System.Windows.Forms.Button()
        Me.btnFinMano = New System.Windows.Forms.Button()
        Me.lblCartaUnoMaquina = New System.Windows.Forms.Label()
        Me.lblCartaDosMaquina = New System.Windows.Forms.Label()
        Me.pbarJuego = New System.Windows.Forms.ProgressBar()
        Me.lblValorManoMaquina = New System.Windows.Forms.Label()
        Me.lblManoActual = New System.Windows.Forms.Label()
        Me.gboxMaquina = New System.Windows.Forms.GroupBox()
        Me.gboxJugador = New System.Windows.Forms.GroupBox()
        Me.lblGanadas = New System.Windows.Forms.Label()
        Me.lblPerdidas = New System.Windows.Forms.Label()
        Me.gboxMaquina.SuspendLayout()
        Me.gboxJugador.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTipoPartida
        '
        Me.lblTipoPartida.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTipoPartida.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.lblTipoPartida.Location = New System.Drawing.Point(37, 9)
        Me.lblTipoPartida.Name = "lblTipoPartida"
        Me.lblTipoPartida.Size = New System.Drawing.Size(273, 30)
        Me.lblTipoPartida.TabIndex = 0
        Me.lblTipoPartida.Text = "Tipo De Partida: "
        '
        'cmbCartasRepartidas
        '
        Me.cmbCartasRepartidas.FormattingEnabled = True
        Me.cmbCartasRepartidas.Location = New System.Drawing.Point(125, 24)
        Me.cmbCartasRepartidas.Name = "cmbCartasRepartidas"
        Me.cmbCartasRepartidas.Size = New System.Drawing.Size(56, 21)
        Me.cmbCartasRepartidas.TabIndex = 1
        Me.cmbCartasRepartidas.Text = "Cartas Repartidas"
        '
        'lblValorMano
        '
        Me.lblValorMano.AutoSize = True
        Me.lblValorMano.Location = New System.Drawing.Point(6, 67)
        Me.lblValorMano.Name = "lblValorMano"
        Me.lblValorMano.Size = New System.Drawing.Size(93, 13)
        Me.lblValorMano.TabIndex = 2
        Me.lblValorMano.Text = "Valor de tu mano: "
        '
        'lblCartasRepartidas
        '
        Me.lblCartasRepartidas.AutoSize = True
        Me.lblCartasRepartidas.Location = New System.Drawing.Point(6, 24)
        Me.lblCartasRepartidas.Name = "lblCartasRepartidas"
        Me.lblCartasRepartidas.Size = New System.Drawing.Size(97, 13)
        Me.lblCartasRepartidas.TabIndex = 3
        Me.lblCartasRepartidas.Text = "Cartas Repartidas: "
        '
        'btnPedirCarta
        '
        Me.btnPedirCarta.Location = New System.Drawing.Point(280, 82)
        Me.btnPedirCarta.Name = "btnPedirCarta"
        Me.btnPedirCarta.Size = New System.Drawing.Size(75, 23)
        Me.btnPedirCarta.TabIndex = 4
        Me.btnPedirCarta.Text = "Pedir Carta"
        Me.btnPedirCarta.UseVisualStyleBackColor = True
        '
        'btnFinMano
        '
        Me.btnFinMano.Location = New System.Drawing.Point(280, 123)
        Me.btnFinMano.Name = "btnFinMano"
        Me.btnFinMano.Size = New System.Drawing.Size(75, 23)
        Me.btnFinMano.TabIndex = 5
        Me.btnFinMano.Text = "Fin de Mano"
        Me.btnFinMano.UseVisualStyleBackColor = True
        '
        'lblCartaUnoMaquina
        '
        Me.lblCartaUnoMaquina.AutoSize = True
        Me.lblCartaUnoMaquina.Location = New System.Drawing.Point(6, 16)
        Me.lblCartaUnoMaquina.Name = "lblCartaUnoMaquina"
        Me.lblCartaUnoMaquina.Size = New System.Drawing.Size(105, 13)
        Me.lblCartaUnoMaquina.TabIndex = 6
        Me.lblCartaUnoMaquina.Text = "Carta Uno Maquina: "
        '
        'lblCartaDosMaquina
        '
        Me.lblCartaDosMaquina.AutoSize = True
        Me.lblCartaDosMaquina.Location = New System.Drawing.Point(7, 41)
        Me.lblCartaDosMaquina.Name = "lblCartaDosMaquina"
        Me.lblCartaDosMaquina.Size = New System.Drawing.Size(104, 13)
        Me.lblCartaDosMaquina.TabIndex = 7
        Me.lblCartaDosMaquina.Text = "Carta Dos Maquina: "
        '
        'pbarJuego
        '
        Me.pbarJuego.Location = New System.Drawing.Point(52, 413)
        Me.pbarJuego.Name = "pbarJuego"
        Me.pbarJuego.Size = New System.Drawing.Size(529, 23)
        Me.pbarJuego.TabIndex = 8
        '
        'lblValorManoMaquina
        '
        Me.lblValorManoMaquina.AutoSize = True
        Me.lblValorManoMaquina.Location = New System.Drawing.Point(6, 67)
        Me.lblValorManoMaquina.Name = "lblValorManoMaquina"
        Me.lblValorManoMaquina.Size = New System.Drawing.Size(126, 13)
        Me.lblValorManoMaquina.TabIndex = 9
        Me.lblValorManoMaquina.Text = "Valor Mano de Maquina: "
        '
        'lblManoActual
        '
        Me.lblManoActual.BackColor = System.Drawing.SystemColors.Highlight
        Me.lblManoActual.Location = New System.Drawing.Point(368, 9)
        Me.lblManoActual.Name = "lblManoActual"
        Me.lblManoActual.Size = New System.Drawing.Size(225, 30)
        Me.lblManoActual.TabIndex = 10
        Me.lblManoActual.Text = "Mano Actual: "
        '
        'gboxMaquina
        '
        Me.gboxMaquina.Controls.Add(Me.lblCartaUnoMaquina)
        Me.gboxMaquina.Controls.Add(Me.lblCartaDosMaquina)
        Me.gboxMaquina.Controls.Add(Me.lblValorManoMaquina)
        Me.gboxMaquina.Location = New System.Drawing.Point(393, 66)
        Me.gboxMaquina.Name = "gboxMaquina"
        Me.gboxMaquina.Size = New System.Drawing.Size(188, 100)
        Me.gboxMaquina.TabIndex = 11
        Me.gboxMaquina.TabStop = False
        Me.gboxMaquina.Text = "Maquina"
        '
        'gboxJugador
        '
        Me.gboxJugador.Controls.Add(Me.lblCartasRepartidas)
        Me.gboxJugador.Controls.Add(Me.lblValorMano)
        Me.gboxJugador.Controls.Add(Me.cmbCartasRepartidas)
        Me.gboxJugador.Location = New System.Drawing.Point(52, 66)
        Me.gboxJugador.Name = "gboxJugador"
        Me.gboxJugador.Size = New System.Drawing.Size(188, 100)
        Me.gboxJugador.TabIndex = 12
        Me.gboxJugador.TabStop = False
        Me.gboxJugador.Text = "Jugador: "
        '
        'lblGanadas
        '
        Me.lblGanadas.AutoSize = True
        Me.lblGanadas.Location = New System.Drawing.Point(22, 292)
        Me.lblGanadas.Name = "lblGanadas"
        Me.lblGanadas.Size = New System.Drawing.Size(0, 13)
        Me.lblGanadas.TabIndex = 13
        '
        'lblPerdidas
        '
        Me.lblPerdidas.AutoSize = True
        Me.lblPerdidas.Location = New System.Drawing.Point(25, 353)
        Me.lblPerdidas.Name = "lblPerdidas"
        Me.lblPerdidas.Size = New System.Drawing.Size(0, 13)
        Me.lblPerdidas.TabIndex = 14
        '
        'formJuego
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.proyectoVisual.My.Resources.Resources.blackJackMesa
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(631, 448)
        Me.Controls.Add(Me.lblPerdidas)
        Me.Controls.Add(Me.lblGanadas)
        Me.Controls.Add(Me.gboxJugador)
        Me.Controls.Add(Me.gboxMaquina)
        Me.Controls.Add(Me.lblManoActual)
        Me.Controls.Add(Me.pbarJuego)
        Me.Controls.Add(Me.btnFinMano)
        Me.Controls.Add(Me.btnPedirCarta)
        Me.Controls.Add(Me.lblTipoPartida)
        Me.Name = "formJuego"
        Me.Text = "BlackJack"
        Me.gboxMaquina.ResumeLayout(False)
        Me.gboxMaquina.PerformLayout()
        Me.gboxJugador.ResumeLayout(False)
        Me.gboxJugador.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTipoPartida As Label
    Friend WithEvents cmbCartasRepartidas As ComboBox
    Friend WithEvents lblValorMano As Label
    Friend WithEvents lblCartasRepartidas As Label
    Friend WithEvents btnPedirCarta As Button
    Friend WithEvents btnFinMano As Button
    Friend WithEvents lblCartaUnoMaquina As Label
    Friend WithEvents lblCartaDosMaquina As Label
    Friend WithEvents pbarJuego As ProgressBar
    Friend WithEvents lblValorManoMaquina As Label
    Friend WithEvents lblManoActual As Label
    Friend WithEvents gboxMaquina As GroupBox
    Friend WithEvents gboxJugador As GroupBox
    Friend WithEvents lblGanadas As Label
    Friend WithEvents lblPerdidas As Label
End Class
